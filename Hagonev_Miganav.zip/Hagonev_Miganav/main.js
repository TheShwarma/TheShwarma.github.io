// import 'jquery'

function inject(source) {
	// inject JS in order to retrieve page variables and communicate with them
	const j = document.createElement('script'), f = document.getElementsByTagName('script')[0];
	j.textContent = source
	f.parentNode.insertBefore(j, f)
	f.parentNode.removeChild(j)
}

function mainCode() {
	$('#fakeDl').ready(() => {
		const dButton = $('#fakeDL') // the unclickable button
		const textLabel = dButton.children('span').first() // its text
		textLabel.text("הורד את הפרק")
		dButton.removeClass("download") // prevent the site from making it unpressable
		
		dButton.on('click', () => { // set download on click
			dButton.removeClass("btn-green").addClass("btn-blue")
			textLabel.text("ההורדה מתבצעת ברקע...")
			let seriesName = $('div.poster').children('div.container').children('h1').text()
			if (seriesName.includes('/')) { // has both names, in Hebrew and English
				// take one
				seriesName = seriesName.substring(0, seriesName.indexOf('/')).trim()
			}

			fetch("https:" + $('#videojs_html5_api').attr('src'), {credentials: 'include'})
				.then(resp => resp.blob())
				.then(blob => {
			 		const url = window.URL.createObjectURL(blob);
					const a = document.createElement('a')
			  		a.style.display = 'none'
			  		a.href = url
			  		a.download = `${seriesName} עונה ${season} פרק ${episode}.mp4`
			  		document.body.appendChild(a)
			  		a.click()
			  		window.URL.revokeObjectURL(url)
					textLabel.text("הורד בהצלחה!")
			})
		}
	)
	})
}

if (!window.location.href.includes("sdarot")) {
	console.log("Hagonev Miganav: Script ran for some odd reason, but the site is not Sdarot!")
} else {
	console.log("Hagonev Miganav: Started")
	inject(mainCode.toString() + "; mainCode()")
}
