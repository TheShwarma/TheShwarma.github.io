// import 'jquery'

function inject(source) {
	// inject JS in order to retrieve page variables and communicate with them.
	const j = document.createElement('script'), f = document.getElementsByTagName('script')[0];
	j.textContent = source
	f.parentNode.insertBefore(j, f)
	f.parentNode.removeChild(j)
}

function downloadContent() {
	$('#fakeDl').ready(() => {
		const dButton = $('#fakeDL') // the unclickable button
		const textLabel = dButton.children('span').first() // its text
		textLabel.text("גנוב את הפרק")
		dButton.removeClass("download") // prevent the site from making it unpressable
		
		dButton.on('click', () => { // set download on click
			dButton.removeClass("btn-green").addClass("btn-blue")
			textLabel.text("הגניבה מתבצעת...")
			fetch("https:" + $('#videojs_html5_api').attr('src'), {credentials: 'include'})
				.then(resp => resp.blob())
				.then(blob => {
			 		const url = window.URL.createObjectURL(blob);
					const a = document.createElement('a')
			  		a.style.display = 'none'
			  		a.href = url
			  		a.download = 'sdarot-video.mp4'
			  		document.body.appendChild(a)
			  		a.click()
			  		window.URL.revokeObjectURL(url)
					textLabel.text("נגנב בהצלחה!")
			})
		}
	)
	$("p.col-lg-4.col-md-4.col-sm-4").text(`סדרות הינו אתר המציע חווית צפייה ישירה של סדרות שונות מהארץ ומחו"ל, במגוון רחב של ז'אנרים והתאמות לקהלי יעד שונים, בניהם משפחה, ילדים, גיל הרך ועוד. לכל הסדרות מחו"ל הנמצאות באתר סדרות, מצורפות כתוביות בשפה העברית (נקרא גם "תרגום מובנה"). גם בסדרות הישראליות קיים תרגום ברוב המקרים.
	אתר סדרות מתעדכן על בסיס יומי, חוץ מהסדרה שטיסל שמגיעה בדילי מעצבן של יומיים, מאפשר צפייה ישירה מכל זמן ומקום בעולם, בחינם וללא הגבלה, לא כולל השלושים שניות המעצבנות שאנחנו מכריחים את הצופים שלנו לחכות והאיכות המחורבנת של 480p שמהווה את המגבלה אם אתם לא "תורמים" לנו.
	צוות אתר סדרות שם דגש על שימוש בטכנולוגיות חדשניות על מנת להעביר לצופים את התוכן באיכות מקסימלית, ללא פשרות.
	
	(תגיד יוסי, הם יאמינו לזה?)
	(נראה לך? טכנולוגיות חדשניות? הכל PHP וjQuery מלאים בפרצות אבטחה שתלמידי תיכון פורצים בחצי שעה. ו"באיכות מקסימלית"? אנחנו פאקינג כותבים שצריך מנוי בשביל "צפייה באיכות HD", אז איך אפשר לטעון שאנחנו מציגים את התוכן ב"איכות מקסימלית"?)
	(באסה...)`)

	})
}

if (!window.location.href.includes("sdarot")) {
	console.log("Hagonev Miganav: Script ran for some odd reason, but the site is not Sdarot!")
	console.log("The site is " + window.location.href)
} else {
	console.log("הגונב מגנב פטור!")
	inject(downloadContent.toString() + "; downloadContent()")
}